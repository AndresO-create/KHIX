# FIXED

GrLib/fonts/fontClean7x10.obj: ../GrLib/fonts/fontClean7x10.c
GrLib/fonts/fontClean7x10.obj: /Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/stdint.h
GrLib/fonts/fontClean7x10.obj: /Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/_ti_config.h
GrLib/fonts/fontClean7x10.obj: /Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/linkage.h
GrLib/fonts/fontClean7x10.obj: /Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/_stdint40.h
GrLib/fonts/fontClean7x10.obj: /Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/sys/stdint.h
GrLib/fonts/fontClean7x10.obj: /Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/sys/cdefs.h
GrLib/fonts/fontClean7x10.obj: /Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/sys/_types.h
GrLib/fonts/fontClean7x10.obj: /Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/machine/_types.h
GrLib/fonts/fontClean7x10.obj: /Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/machine/_stdint.h
GrLib/fonts/fontClean7x10.obj: /Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/sys/_stdint.h
GrLib/fonts/fontClean7x10.obj: /Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/stdbool.h
GrLib/fonts/fontClean7x10.obj: /Users/andresortiz/workspace_ccstheia/OkLastTimeBeforeIGiveUp/GrLib/grlib/grlib.h
GrLib/fonts/fontClean7x10.obj: /Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/assert.h

../GrLib/fonts/fontClean7x10.c:

/Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/stdint.h:

/Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/_ti_config.h:

/Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/linkage.h:

/Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/_stdint40.h:

/Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/sys/stdint.h:

/Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/sys/cdefs.h:

/Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/sys/_types.h:

/Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/machine/_types.h:

/Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/machine/_stdint.h:

/Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/sys/_stdint.h:

/Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/stdbool.h:

/Users/andresortiz/workspace_ccstheia/OkLastTimeBeforeIGiveUp/GrLib/grlib/grlib.h:

/Applications/ti/ccs2101/ccs/tools/compiler/ti-cgt-msp430_21.6.3.LTS/include/assert.h:

